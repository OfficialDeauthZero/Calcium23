HDR Bloom and Eye Adaptation (Automatic Exposure).

Based on Unity Post Processing Stack.

Compact code prepared for better understanding algorithm.

Set Options: Rendering Path: Deferred, Allow HDR = True, Linear Color Space
