Convert scalar field to triangle mesh.

Add script to gameobject and assign public variables. Set camera position (0, 0, -15).

3D SDF function definition: file ScalarField.compute, function "Map".