HLSL DirectX Shader Model 3.0 startup.
