Directory contains HLSL and GLSL code for standalone executables. 
