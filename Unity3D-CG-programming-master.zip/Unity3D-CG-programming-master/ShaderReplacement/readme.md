References:
https://docs.unity3d.com/Manual/SL-ShaderReplacement.html
