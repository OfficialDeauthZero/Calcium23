Unity3D GLSL shader programs.
Enable OpenGL in Unity3D -> set -force-glcore parameter to editor executable, for instance:
"C:\Program Files\Unity\Editor\Unity.exe" -force-glcore
