Directory contains my procedural textures.
