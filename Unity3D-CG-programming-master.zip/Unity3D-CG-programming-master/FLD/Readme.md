Fisher Linear Discriminant.
