Convert polygonal mesh into 3D texture and render with raymarching technique.
