Directory contains tools related with shader programming theory.
