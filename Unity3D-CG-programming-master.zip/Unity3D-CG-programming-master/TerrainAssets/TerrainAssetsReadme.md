Various terrain assets for testing purposes.
Drag and drop to "Scene" view.
