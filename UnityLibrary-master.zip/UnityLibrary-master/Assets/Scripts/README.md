# Scripts
The game logic. the most important part of game development.

Do you want to make a car? do you try to invent the Wheel from the beginning? no one do it.

So we have gathered pre made ready-to-use scripts here just for you.

If you have experienced any errors or problems, [send it to us](https://github.com/UnityCommunity/UnityLibrary/issues), we are here to help.

## License
[MIT](https://github.com/UnityCommunity/UnityLibrary/blob/master/LICENSE.md) @ [Unity Community](https://github.com/UnityCommunity/)

Made with :heart: by [Unity Community](https://github.com/UnityCommunity/)
