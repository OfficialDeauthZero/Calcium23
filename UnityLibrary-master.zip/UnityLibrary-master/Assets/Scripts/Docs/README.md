# Docs
Sometimes we see some missing, outdated or broken documentations and examples at Unity official documentation Manual or Scripting API, so we have collected some of them and made a good examples and documentations about them.

Do you found a missing documentation or example? [File it here and let us add it](https://github.com/UnityCommunity/UnityLibrary/issues)

## License
[MIT](https://github.com/UnityCommunity/UnityLibrary/blob/master/LICENSE.md) @ [Unity Community](https://github.com/UnityCommunity/)

Made with :heart: by [Unity Community](https://github.com/UnityCommunity/)
