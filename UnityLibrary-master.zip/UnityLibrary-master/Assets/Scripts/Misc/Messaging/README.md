* SendMessage substitute for global messaging without object references;
* To subscribe to event, one must AddListener to event string and provide a callback method (f.e. OnEnable );
* To unsubscribe to event, one must RemoveListener to event string and provide a callback method (f.e. OnDisable );
