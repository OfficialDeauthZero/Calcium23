# Editor Scripts
Extend the Unity Editor with the power of Community.

Experiencing errors and problems, no worry, [File them, and let us fix them](https://github.com/UnityCommunity/UnityLibrary/issues)

## License
[MIT](https://github.com/UnityCommunity/UnityLibrary/blob/master/LICENSE.md) @ [Unity Community](https://github.com/UnityCommunity/)

Made with :heart: by [Unity Community](https://github.com/UnityCommunity/)
