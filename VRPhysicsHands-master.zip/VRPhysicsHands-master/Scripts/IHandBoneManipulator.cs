﻿namespace VRPhysicsHands
{
    public interface IHandBoneManipulator
    {
        HandBoneValues GetValues();
        bool ShowHand();
    }
}