﻿using UnityEditor;

namespace VRPhysicsHands
{
    [CustomEditor(typeof(HandEmulator)), CanEditMultipleObjects]
    public class HandEmulatorEditor : Editor
    {
    }
}