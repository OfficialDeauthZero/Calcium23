﻿using UnityEditor;

namespace VRPhysicsHands
{
    [CustomEditor(typeof(OculusTouchInput)), CanEditMultipleObjects]
    public class OculusTouchInputEditor : Editor
    {
    }
}