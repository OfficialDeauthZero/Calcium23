---
title: nodes-additional-settings
---

This node has some additional settings that you can access from the Graph Inspector:
