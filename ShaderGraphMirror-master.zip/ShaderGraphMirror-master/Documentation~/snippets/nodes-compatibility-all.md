---
title: nodes-compatibility-all
---

This node is supported on the following render pipelines:

<table>
<thead>
<tr>
<th><strong>Built-in Render Pipeline</strong></th>
<th><strong>Universal Render Pipeline (URP)</strong></th>
<th><strong>High Definition Render Pipeline (HDRP)</strong></th>
</tr>
</thead>
<tbody>
<tr>
<td>Yes</td>
<td>Yes</td>
<td>Yes</td>
</tr>
</tbody>
</table>
