---
title: nodes-subgraph-node
---

> [!NOTE]
> This node is a Subgraph node: it represents a Subgraph instead of directly representing Unity's shader code. Double-click the node in any Shader Graph to view its Subgraph.
