---
title: nodes-single-control
---

The node has one control:
