---
title: nodes-fragment-only
---

This node can only connect to a Block node in the **Fragment** Context of your Shader Graph. For more information on Block nodes and Contexts, see [Master Stack](Master-Stack.md).
