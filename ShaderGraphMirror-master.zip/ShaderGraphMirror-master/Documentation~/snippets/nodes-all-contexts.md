---
title: nodes-all-contexts.md
---

This node can also be connected to any Block node in either Context. For more information on Block nodes and Contexts, see <a href="Master-Stack.md">Master Stack</a>.
