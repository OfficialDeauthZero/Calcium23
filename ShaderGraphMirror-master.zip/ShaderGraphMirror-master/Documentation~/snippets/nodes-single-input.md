---
title: nodes-single-input
---

The node has one input port:
