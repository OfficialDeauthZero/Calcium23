---
title: nodes-controls
---

The node has the following controls:
