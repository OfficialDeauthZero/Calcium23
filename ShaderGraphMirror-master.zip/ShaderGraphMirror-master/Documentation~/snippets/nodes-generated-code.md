---
title: nodes-generated-code
---

The following example code is a possible outcome of this node written in HLSL code:
