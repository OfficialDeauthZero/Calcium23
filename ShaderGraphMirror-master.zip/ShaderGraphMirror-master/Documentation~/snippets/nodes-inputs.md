---
title: nodes-inputs
---

The node has the following input ports:
