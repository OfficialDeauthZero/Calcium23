---
title: nodes-single-output
---

The node has one output port:
