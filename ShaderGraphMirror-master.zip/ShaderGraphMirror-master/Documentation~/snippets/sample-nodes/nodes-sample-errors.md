---
title: nodes-sample-errors
---

> [!NOTE]
> If you experience texture sampling errors while using this node in a graph with Custom Function Nodes or Sub Graphs, upgrade to Shader Graph version 10.3 or later.
