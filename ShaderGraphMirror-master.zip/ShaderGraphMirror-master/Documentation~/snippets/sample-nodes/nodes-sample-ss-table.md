---
title: nodes-sample-ss-table
---

<tr>
<td><strong>Sampler</strong></td>
<td>Sampler State</td>
<td>Default Sampler State</td>
<td>The Sampler State and corresponding settings that the node should use to sample the texture.</td>
</tr>
