---
title: nodes-sample-uv-table
---

<tr>
<td><strong>UV</strong></td>
<td>Vector 2</td>
<td>UV</td>
<td>The UV coordinates that the node should use to sample the texture.</td>
</tr>
