---
title: nodes-outputs
---

The node has the following output ports:
