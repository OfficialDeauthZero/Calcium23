# Eye Index Node

## Description

Provides access to the **Eye Index** when stereo rendering is enabled.

## Ports

| Name   | Direction  | Type  | Binding | Description |
|:-------|:-----------|:------|:--------|:------------|
| Out    | Output     | Float | None    | **Eye Index** for the camera of a stereo draw. |
