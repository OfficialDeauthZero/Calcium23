using System;

namespace UnityEditor.ShaderGraph.Legacy
{
    [Serializable]
    class ShaderInput0
    {
        public SerializableGuid m_Guid;
    }
}
