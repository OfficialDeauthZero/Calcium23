using System;
using UnityEngine;

namespace UnityEditor.ShaderGraph.Legacy
{
    [Serializable]
    class SlotReference0
    {
        public int m_SlotId;

        public string m_NodeGUIDSerialized;
    }
}
