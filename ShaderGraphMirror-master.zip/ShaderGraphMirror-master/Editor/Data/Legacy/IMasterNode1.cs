namespace UnityEditor.ShaderGraph.Legacy
{
    public interface IMasterNode1
    {
    }
}
