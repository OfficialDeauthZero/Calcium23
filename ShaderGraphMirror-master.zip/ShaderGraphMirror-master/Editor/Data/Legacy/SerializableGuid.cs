using System;
using UnityEngine;

namespace UnityEditor.ShaderGraph.Legacy
{
    [Serializable]
    class SerializableGuid
    {
        public string m_GuidSerialized;
    }
}
