using System;

namespace UnityEditor.ShaderGraph
{
    interface IGroupItem
    {
        GroupData group { get; set; }
    }
}
