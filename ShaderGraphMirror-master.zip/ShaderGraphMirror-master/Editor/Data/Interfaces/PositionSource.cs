using System;

namespace UnityEditor.ShaderGraph.Internal
{
    public enum PositionSource
    {
        Default,
        Predisplacement,
    }
}
